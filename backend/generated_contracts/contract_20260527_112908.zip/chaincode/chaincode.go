package chaincode

import (
	"encoding/json"
	"fmt"
	"time"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)



type Status int

const (
	DISABLED Status = iota
	ENABLED
	WAITING
	COMPLETED
)



type Message struct {
	ID       string       `json:"id"`
	Sender   string       `json:"sender"`
	Receiver string       `json:"receiver"`
	State    Status       `json:"state"`
}


type Gateway struct {
	ID    string       `json:"id"`
	State Status       `json:"state"`
}


type Event struct {
	ID    string       `json:"id"`
	State Status       `json:"state"`
}



type BPV struct {}


type SmartContract struct {
	contractapi.Contract
}


type ProcessInstance struct {
	ID        string                 `json:"id"`
	StartedBy string                 `json:"startedBy"`
	StartedAt int64                  `json:"startedAt"`

	Messages  map[string]Message     `json:"messages"`
	Events    map[string]Event       `json:"events"`
	Gateways  map[string]Gateway     `json:"gateways"`
	Memory    BPV                    `json:"memory"`
}



func (cc *SmartContract) getInstance(ctx contractapi.TransactionContextInterface, instanceID string) (*ProcessInstance, error) {
	data, err := ctx.GetStub().GetState(instanceID)
	if err != nil { 
		return nil, fmt.Errorf("failed to read instance: %v", err) 
	}
	if data == nil { 
		return nil, fmt.Errorf("instance %s not found", instanceID) 
	}

	var inst ProcessInstance
	if err := json.Unmarshal(data, &inst); err != nil { 
		return nil, fmt.Errorf("failed to unmarshal instance: %v", err) 
	}
	return &inst, nil
}

func (cc *SmartContract) putInstance(ctx contractapi.TransactionContextInterface, inst *ProcessInstance) error {
	data, err := json.Marshal(inst)
	if err != nil { 
		return fmt.Errorf("failed to marshal instance: %v", err) 
	}
	return ctx.GetStub().PutState(inst.ID, data)
}

func (cc *SmartContract) IsCompleted(inst *ProcessInstance, elementID string) bool {
	if msg, ok := inst.Messages[elementID]; ok { 
		return msg.State == COMPLETED 
	}
	if evt, ok := inst.Events[elementID]; ok { 
		return evt.State == COMPLETED 
	}
	if gtw, ok := inst.Gateways[elementID]; ok { 
		return gtw.State == COMPLETED 
	}
	return false
}


func (cc *SmartContract) GetInstanceState(
    ctx contractapi.TransactionContextInterface,
    instanceID string,
) (*ProcessInstance, error) {
    return cc.getInstance(ctx, instanceID)
}

func (cc *SmartContract) Message_0g07j4n_Send(ctx contractapi.TransactionContextInterface, instanceID string) error {

	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}


	msg, ok := inst.Messages["Message_0g07j4n"]
	if !ok {
		return fmt.Errorf("message Message_0g07j4n not found in instance")
	}

	if msg.State != ENABLED {
		return fmt.Errorf("message Message_0g07j4n is not enabled (current state: %v)", msg.State)
	}

	clientMSP, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return err
	}
	if clientMSP != msg.Sender {
		return fmt.Errorf("participant %s is not authorized to send message Message_0g07j4n (expected sender: %s)",
			clientMSP, msg.Sender)
	}



	msg.State = WAITING
	inst.Messages["Message_0g07j4n"] = msg

	ctx.GetStub().SetEvent("Message_0g07j4n_sent:"+instanceID, []byte("Message sent"))



	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Message_0g07j4n_Confirm(ctx contractapi.TransactionContextInterface, instanceID string) error {
	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}

	msg, ok := inst.Messages["Message_0g07j4n"]
	if !ok {
		return fmt.Errorf("message Message_0g07j4n not found in instance")
	}

	if msg.State != WAITING {
		return fmt.Errorf("message Message_0g07j4n is not waiting for confirmation (current state: %v)", msg.State)
	}

	clientMSP, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return err
	}
	if clientMSP != msg.Receiver {
		return fmt.Errorf("participant %s is not authorized to confirm message Message_0g07j4n", clientMSP)
	}

	msg.State = COMPLETED
	inst.Messages["Message_0g07j4n"] = msg

	ctx.GetStub().SetEvent("Message_0g07j4n_confirmed:"+instanceID, []byte("Message confirmed"))


{
    elem := inst.Events["Event_09we3hr"]
    elem.State = ENABLED
    inst.Events["Event_09we3hr"] = elem
}



	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Event_1gba1fg(ctx contractapi.TransactionContextInterface, instanceID string) error {
	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}

	event, ok := inst.Events["Event_1gba1fg"]
	if !ok {
		return fmt.Errorf("event Event_1gba1fg not found in instance")
	}

	if event.State != ENABLED {
		return fmt.Errorf("event Event_1gba1fg is not enabled (current state: %v)", event.State)
	}

	event.State = COMPLETED
	inst.Events["Event_1gba1fg"] = event

	ctx.GetStub().SetEvent("Event_1gba1fg_executed:"+instanceID, []byte("Event executed"))


{
    elem := inst.Messages["Message_0g07j4n"]
    elem.State = ENABLED
    inst.Messages["Message_0g07j4n"] = elem
}



	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Event_09we3hr(ctx contractapi.TransactionContextInterface, instanceID string) error {
	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}

	event, ok := inst.Events["Event_09we3hr"]
	if !ok {
		return fmt.Errorf("event Event_09we3hr not found in instance")
	}

	if event.State != ENABLED {
		return fmt.Errorf("event Event_09we3hr is not enabled (current state: %v)", event.State)
	}

	event.State = COMPLETED
	inst.Events["Event_09we3hr"] = event

	ctx.GetStub().SetEvent("Event_09we3hr_executed:"+instanceID, []byte("Event executed"))





	return cc.putInstance(ctx, inst)
}



func (cc *SmartContract) CreateInstance(ctx contractapi.TransactionContextInterface, instanceID string) error {
	stub := ctx.GetStub()

	existing, err := stub.GetState(instanceID)
	if err != nil {
		return fmt.Errorf("failed to check instance: %v", err)
	}
	if existing != nil {
		return fmt.Errorf("instance %s already exists", instanceID)
	}

	initiator, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return fmt.Errorf("failed to get client identity: %v", err)
	}

	inst := ProcessInstance{
		ID:        instanceID,
		StartedBy: initiator,
		StartedAt: time.Now().Unix(),

		Messages: map[string]Message{
		"Message_0g07j4n": {ID: "Message_0g07j4n", Sender: "Org1MSP", Receiver: "Org2MSP", State: DISABLED},
		},
		Events: map[string]Event{
		"Event_1gba1fg": {ID: "Event_1gba1fg", State: ENABLED},
		"Event_09we3hr": {ID: "Event_09we3hr", State: DISABLED},
		},
		Gateways: map[string]Gateway{

		},
		Memory:   BPV{},
	}

	data, err := json.Marshal(inst)
	if err != nil {
		return fmt.Errorf("failed to marshal instance: %v", err)
	}
	return stub.PutState(instanceID, data)
}