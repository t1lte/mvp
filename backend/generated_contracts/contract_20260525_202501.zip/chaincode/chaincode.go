package chaincode

import (
	"encoding/json"
	"fmt"
	"time"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)



type Status int

const (
	DISABLED Status = iota
	ENABLED
	WAITING
	COMPLETED
)



type Message struct {
	ID       string       `json:"id"`
	Sender   string       `json:"sender"`
	Receiver string       `json:"receiver"`
	State    Status       `json:"state"`
}


type Gateway struct {
	ID    string       `json:"id"`
	State Status       `json:"state"`
}


type Event struct {
	ID    string       `json:"id"`
	State Status       `json:"state"`
}



type BPV struct {
	Message1wvh9ceHui string `json:"Message_1wvh9ce_hui"`
	Message1hmrhxxSisky string `json:"Message_1hmrhxx_sisky"`
}


type SmartContract struct {
	contractapi.Contract
}


type ProcessInstance struct {
	ID        string                 `json:"id"`
	StartedBy string                 `json:"startedBy"`
	StartedAt int64                  `json:"startedAt"`

	Messages  map[string]Message     `json:"messages"`
	Events    map[string]Event       `json:"events"`
	Gateways  map[string]Gateway     `json:"gateways"`
	Memory    BPV                    `json:"memory"`
}



func (cc *SmartContract) getInstance(ctx contractapi.TransactionContextInterface, instanceID string) (*ProcessInstance, error) {
	data, err := ctx.GetStub().GetState(instanceID)
	if err != nil { 
		return nil, fmt.Errorf("failed to read instance: %v", err) 
	}
	if data == nil { 
		return nil, fmt.Errorf("instance %s not found", instanceID) 
	}

	var inst ProcessInstance
	if err := json.Unmarshal(data, &inst); err != nil { 
		return nil, fmt.Errorf("failed to unmarshal instance: %v", err) 
	}
	return &inst, nil
}

func (cc *SmartContract) putInstance(ctx contractapi.TransactionContextInterface, inst *ProcessInstance) error {
	data, err := json.Marshal(inst)
	if err != nil { 
		return fmt.Errorf("failed to marshal instance: %v", err) 
	}
	return ctx.GetStub().PutState(inst.ID, data)
}

func (cc *SmartContract) IsCompleted(inst *ProcessInstance, elementID string) bool {
	if msg, ok := inst.Messages[elementID]; ok { 
		return msg.State == COMPLETED 
	}
	if evt, ok := inst.Events[elementID]; ok { 
		return evt.State == COMPLETED 
	}
	if gtw, ok := inst.Gateways[elementID]; ok { 
		return gtw.State == COMPLETED 
	}
	return false
}


func (cc *SmartContract) GetInstanceState(
    ctx contractapi.TransactionContextInterface,
    instanceID string,
) (*ProcessInstance, error) {
    return cc.getInstance(ctx, instanceID)
}

func (cc *SmartContract) Message_1hmrhxx_Send(ctx contractapi.TransactionContextInterface, instanceID string, Message1hmrhxxSisky string) error {

	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}


	msg, ok := inst.Messages["Message_1hmrhxx"]
	if !ok {
		return fmt.Errorf("message Message_1hmrhxx not found in instance")
	}

	if msg.State != ENABLED {
		return fmt.Errorf("message Message_1hmrhxx is not enabled (current state: %v)", msg.State)
	}

	clientMSP, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return err
	}
	if clientMSP != msg.Sender {
		return fmt.Errorf("participant %s is not authorized to send message Message_1hmrhxx (expected sender: %s)",
			clientMSP, msg.Sender)
	}


	inst.Memory.Message1hmrhxxSisky = Message1hmrhxxSisky

	msg.State = WAITING
	inst.Messages["Message_1hmrhxx"] = msg

	ctx.GetStub().SetEvent("Message_1hmrhxx_sent:"+instanceID, []byte("Message sent"))



	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Message_1hmrhxx_Confirm(ctx contractapi.TransactionContextInterface, instanceID string) error {
	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}

	msg, ok := inst.Messages["Message_1hmrhxx"]
	if !ok {
		return fmt.Errorf("message Message_1hmrhxx not found in instance")
	}

	if msg.State != WAITING {
		return fmt.Errorf("message Message_1hmrhxx is not waiting for confirmation (current state: %v)", msg.State)
	}

	clientMSP, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return err
	}
	if clientMSP != msg.Receiver {
		return fmt.Errorf("participant %s is not authorized to confirm message Message_1hmrhxx", clientMSP)
	}

	msg.State = COMPLETED
	inst.Messages["Message_1hmrhxx"] = msg

	ctx.GetStub().SetEvent("Message_1hmrhxx_confirmed:"+instanceID, []byte("Message confirmed"))


{
    elem := inst.Gateways["Gateway_1bihbff"]
    elem.State = ENABLED
    inst.Gateways["Gateway_1bihbff"] = elem
}



	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Message_1wvh9ce_Send(ctx contractapi.TransactionContextInterface, instanceID string, Message1wvh9ceHui string) error {

	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}


	msg, ok := inst.Messages["Message_1wvh9ce"]
	if !ok {
		return fmt.Errorf("message Message_1wvh9ce not found in instance")
	}

	if msg.State != ENABLED {
		return fmt.Errorf("message Message_1wvh9ce is not enabled (current state: %v)", msg.State)
	}

	clientMSP, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return err
	}
	if clientMSP != msg.Sender {
		return fmt.Errorf("participant %s is not authorized to send message Message_1wvh9ce (expected sender: %s)",
			clientMSP, msg.Sender)
	}


	inst.Memory.Message1wvh9ceHui = Message1wvh9ceHui

	msg.State = WAITING
	inst.Messages["Message_1wvh9ce"] = msg

	ctx.GetStub().SetEvent("Message_1wvh9ce_sent:"+instanceID, []byte("Message sent"))



	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Message_1wvh9ce_Confirm(ctx contractapi.TransactionContextInterface, instanceID string) error {
	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}

	msg, ok := inst.Messages["Message_1wvh9ce"]
	if !ok {
		return fmt.Errorf("message Message_1wvh9ce not found in instance")
	}

	if msg.State != WAITING {
		return fmt.Errorf("message Message_1wvh9ce is not waiting for confirmation (current state: %v)", msg.State)
	}

	clientMSP, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return err
	}
	if clientMSP != msg.Receiver {
		return fmt.Errorf("participant %s is not authorized to confirm message Message_1wvh9ce", clientMSP)
	}

	msg.State = COMPLETED
	inst.Messages["Message_1wvh9ce"] = msg

	ctx.GetStub().SetEvent("Message_1wvh9ce_confirmed:"+instanceID, []byte("Message confirmed"))


{
    elem := inst.Events["Event_0o72vtr"]
    elem.State = ENABLED
    inst.Events["Event_0o72vtr"] = elem
}



	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Gateway_1bihbff(ctx contractapi.TransactionContextInterface, instanceID string) error {
	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}

	gw, ok := inst.Gateways["Gateway_1bihbff"]
	if !ok {
		return fmt.Errorf("gateway Gateway_1bihbff not found in instance")
	}

	if gw.State != ENABLED {
		return fmt.Errorf("gateway Gateway_1bihbff is not enabled (current state: %v)", gw.State)
	}

	gw.State = COMPLETED
	inst.Gateways["Gateway_1bihbff"] = gw

	if inst.Memory.Message1hmrhxxSisky != "jopa" {

        {
            elem := inst.Events["Event_1vltxqv"]
            elem.State = ENABLED
            inst.Events["Event_1vltxqv"] = elem
        }
	}
	if inst.Memory.Message1hmrhxxSisky == "jopa" {

        {
            elem := inst.Messages["Message_1wvh9ce"]
            elem.State = ENABLED
            inst.Messages["Message_1wvh9ce"] = elem
        }
	}


	ctx.GetStub().SetEvent("Gateway_1bihbff_executed:"+instanceID, []byte("Gateway executed"))



	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Event_0z3ey09(ctx contractapi.TransactionContextInterface, instanceID string) error {
	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}

	event, ok := inst.Events["Event_0z3ey09"]
	if !ok {
		return fmt.Errorf("event Event_0z3ey09 not found in instance")
	}

	if event.State != ENABLED {
		return fmt.Errorf("event Event_0z3ey09 is not enabled (current state: %v)", event.State)
	}

	event.State = COMPLETED
	inst.Events["Event_0z3ey09"] = event

	ctx.GetStub().SetEvent("Event_0z3ey09_executed:"+instanceID, []byte("Event executed"))


{
    elem := inst.Messages["Message_1hmrhxx"]
    elem.State = ENABLED
    inst.Messages["Message_1hmrhxx"] = elem
}



	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Event_1vltxqv(ctx contractapi.TransactionContextInterface, instanceID string) error {
	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}

	event, ok := inst.Events["Event_1vltxqv"]
	if !ok {
		return fmt.Errorf("event Event_1vltxqv not found in instance")
	}

	if event.State != ENABLED {
		return fmt.Errorf("event Event_1vltxqv is not enabled (current state: %v)", event.State)
	}

	event.State = COMPLETED
	inst.Events["Event_1vltxqv"] = event

	ctx.GetStub().SetEvent("Event_1vltxqv_executed:"+instanceID, []byte("Event executed"))





	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Event_0o72vtr(ctx contractapi.TransactionContextInterface, instanceID string) error {
	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}

	event, ok := inst.Events["Event_0o72vtr"]
	if !ok {
		return fmt.Errorf("event Event_0o72vtr not found in instance")
	}

	if event.State != ENABLED {
		return fmt.Errorf("event Event_0o72vtr is not enabled (current state: %v)", event.State)
	}

	event.State = COMPLETED
	inst.Events["Event_0o72vtr"] = event

	ctx.GetStub().SetEvent("Event_0o72vtr_executed:"+instanceID, []byte("Event executed"))





	return cc.putInstance(ctx, inst)
}



func (cc *SmartContract) CreateInstance(ctx contractapi.TransactionContextInterface, instanceID string) error {
	stub := ctx.GetStub()

	existing, err := stub.GetState(instanceID)
	if err != nil {
		return fmt.Errorf("failed to check instance: %v", err)
	}
	if existing != nil {
		return fmt.Errorf("instance %s already exists", instanceID)
	}

	initiator, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return fmt.Errorf("failed to get client identity: %v", err)
	}

	inst := ProcessInstance{
		ID:        instanceID,
		StartedBy: initiator,
		StartedAt: time.Now().Unix(),

		Messages: map[string]Message{
		"Message_1wvh9ce": {ID: "Message_1wvh9ce", Sender: "Org2MSP", Receiver: "Org1MSP", State: DISABLED},
		"Message_1hmrhxx": {ID: "Message_1hmrhxx", Sender: "Org1MSP", Receiver: "Org2MSP", State: DISABLED},
		},
		Events: map[string]Event{
		"Event_0z3ey09": {ID: "Event_0z3ey09", State: ENABLED},
		"Event_1vltxqv": {ID: "Event_1vltxqv", State: DISABLED},
		"Event_0o72vtr": {ID: "Event_0o72vtr", State: DISABLED},
		},
		Gateways: map[string]Gateway{
		"Gateway_1bihbff": {ID: "Gateway_1bihbff", State: DISABLED},
		},
		Memory:   BPV{},
	}

	data, err := json.Marshal(inst)
	if err != nil {
		return fmt.Errorf("failed to marshal instance: %v", err)
	}
	return stub.PutState(instanceID, data)
}