package chaincode

import (
	"encoding/json"
	"fmt"
	"time"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)



type Status int

const (
	DISABLED Status = iota
	ENABLED
	WAITING
	COMPLETED
)



type Message struct {
	ID       string       `json:"id"`
	Sender   string       `json:"sender"`
	Receiver string       `json:"receiver"`
	State    Status       `json:"state"`
}


type Gateway struct {
	ID    string       `json:"id"`
	State Status       `json:"state"`
}


type Event struct {
	ID    string       `json:"id"`
	State Status       `json:"state"`
}



type BPV struct {
	Message1qrlgwvTest string `json:"Message_1qrlgwv_test"`
}


type SmartContract struct {
	contractapi.Contract
}


type ProcessInstance struct {
	ID        string                 `json:"id"`
	StartedBy string                 `json:"startedBy"`
	StartedAt int64                  `json:"startedAt"`

	Messages  map[string]Message     `json:"messages"`
	Events    map[string]Event       `json:"events"`
	Gateways  map[string]Gateway     `json:"gateways"`
	Memory    BPV                    `json:"memory"`
}



func (cc *SmartContract) getInstance(ctx contractapi.TransactionContextInterface, instanceID string) (*ProcessInstance, error) {
	data, err := ctx.GetStub().GetState(instanceID)
	if err != nil { 
		return nil, fmt.Errorf("failed to read instance: %v", err) 
	}
	if data == nil { 
		return nil, fmt.Errorf("instance %s not found", instanceID) 
	}

	var inst ProcessInstance
	if err := json.Unmarshal(data, &inst); err != nil { 
		return nil, fmt.Errorf("failed to unmarshal instance: %v", err) 
	}
	return &inst, nil
}

func (cc *SmartContract) putInstance(ctx contractapi.TransactionContextInterface, inst *ProcessInstance) error {
	data, err := json.Marshal(inst)
	if err != nil { 
		return fmt.Errorf("failed to marshal instance: %v", err) 
	}
	return ctx.GetStub().PutState(inst.ID, data)
}

func (cc *SmartContract) IsCompleted(inst *ProcessInstance, elementID string) bool {
	if msg, ok := inst.Messages[elementID]; ok { 
		return msg.State == COMPLETED 
	}
	if evt, ok := inst.Events[elementID]; ok { 
		return evt.State == COMPLETED 
	}
	if gtw, ok := inst.Gateways[elementID]; ok { 
		return gtw.State == COMPLETED 
	}
	return false
}


func (cc *SmartContract) GetInstanceState(
    ctx contractapi.TransactionContextInterface,
    instanceID string,
) (*ProcessInstance, error) {
    return cc.getInstance(ctx, instanceID)
}

func (cc *SmartContract) Message_1qrlgwv_Send(ctx contractapi.TransactionContextInterface, instanceID string, Message1qrlgwvTest string) error {

	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}


	msg, ok := inst.Messages["Message_1qrlgwv"]
	if !ok {
		return fmt.Errorf("message Message_1qrlgwv not found in instance")
	}

	if msg.State != ENABLED {
		return fmt.Errorf("message Message_1qrlgwv is not enabled (current state: %v)", msg.State)
	}

	clientMSP, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return err
	}
	if clientMSP != msg.Sender {
		return fmt.Errorf("participant %s is not authorized to send message Message_1qrlgwv (expected sender: %s)",
			clientMSP, msg.Sender)
	}


	inst.Memory.Message1qrlgwvTest = Message1qrlgwvTest

	msg.State = WAITING
	inst.Messages["Message_1qrlgwv"] = msg

	ctx.GetStub().SetEvent("Message_1qrlgwv_sent:"+instanceID, []byte("Message sent"))



	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Message_1qrlgwv_Confirm(ctx contractapi.TransactionContextInterface, instanceID string) error {
	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}

	msg, ok := inst.Messages["Message_1qrlgwv"]
	if !ok {
		return fmt.Errorf("message Message_1qrlgwv not found in instance")
	}

	if msg.State != WAITING {
		return fmt.Errorf("message Message_1qrlgwv is not waiting for confirmation (current state: %v)", msg.State)
	}

	clientMSP, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return err
	}
	if clientMSP != msg.Receiver {
		return fmt.Errorf("participant %s is not authorized to confirm message Message_1qrlgwv", clientMSP)
	}

	msg.State = COMPLETED
	inst.Messages["Message_1qrlgwv"] = msg

	ctx.GetStub().SetEvent("Message_1qrlgwv_confirmed:"+instanceID, []byte("Message confirmed"))


{
    elem := inst.Events["Event_0490zcs"]
    elem.State = ENABLED
    inst.Events["Event_0490zcs"] = elem
}



	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Event_1upou5x(ctx contractapi.TransactionContextInterface, instanceID string) error {
	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}

	event, ok := inst.Events["Event_1upou5x"]
	if !ok {
		return fmt.Errorf("event Event_1upou5x not found in instance")
	}

	if event.State != ENABLED {
		return fmt.Errorf("event Event_1upou5x is not enabled (current state: %v)", event.State)
	}

	event.State = COMPLETED
	inst.Events["Event_1upou5x"] = event

	ctx.GetStub().SetEvent("Event_1upou5x_executed:"+instanceID, []byte("Event executed"))


{
    elem := inst.Messages["Message_1qrlgwv"]
    elem.State = ENABLED
    inst.Messages["Message_1qrlgwv"] = elem
}



	return cc.putInstance(ctx, inst)
}

func (cc *SmartContract) Event_0490zcs(ctx contractapi.TransactionContextInterface, instanceID string) error {
	inst, err := cc.getInstance(ctx, instanceID)
	if err != nil {
		return fmt.Errorf("failed to load instance: %v", err)
	}

	event, ok := inst.Events["Event_0490zcs"]
	if !ok {
		return fmt.Errorf("event Event_0490zcs not found in instance")
	}

	if event.State != ENABLED {
		return fmt.Errorf("event Event_0490zcs is not enabled (current state: %v)", event.State)
	}

	event.State = COMPLETED
	inst.Events["Event_0490zcs"] = event

	ctx.GetStub().SetEvent("Event_0490zcs_executed:"+instanceID, []byte("Event executed"))





	return cc.putInstance(ctx, inst)
}



func (cc *SmartContract) CreateInstance(ctx contractapi.TransactionContextInterface, instanceID string) error {
	stub := ctx.GetStub()

	existing, err := stub.GetState(instanceID)
	if err != nil {
		return fmt.Errorf("failed to check instance: %v", err)
	}
	if existing != nil {
		return fmt.Errorf("instance %s already exists", instanceID)
	}

	initiator, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return fmt.Errorf("failed to get client identity: %v", err)
	}

	inst := ProcessInstance{
		ID:        instanceID,
		StartedBy: initiator,
		StartedAt: time.Now().Unix(),

		Messages: map[string]Message{
		"Message_1qrlgwv": {ID: "Message_1qrlgwv", Sender: "Org1MSP", Receiver: "Org2MSP", State: DISABLED},
		},
		Events: map[string]Event{
		"Event_1upou5x": {ID: "Event_1upou5x", State: ENABLED},
		"Event_0490zcs": {ID: "Event_0490zcs", State: DISABLED},
		},
		Gateways: map[string]Gateway{

		},
		Memory:   BPV{},
	}

	data, err := json.Marshal(inst)
	if err != nil {
		return fmt.Errorf("failed to marshal instance: %v", err)
	}
	return stub.PutState(instanceID, data)
}