package chaincode

import (
	"encoding/json"
	"fmt"
	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)



type ElementState int


const (
	DISABLED ElementState = iota
	ENABLED
	WAITING
	COMPLETED
)



type Message struct {
	ID       string        `json:"id"`
	Sender   string        `json:"sender"`
	Receiver string        `json:"receiver"`
	State    ElementState  `json:"state"`
}


type Gateway struct {
	ID    string        `json:"id"`
	State ElementState  `json:"state"`
}


type Event struct {
	ID    string        `json:"id"`
	State ElementState  `json:"state"`
}


type SmartContract struct {
	contractapi.Contract
}

type StateMemory struct {
	Message0mjk0pmTest string `json:"Message_0mjk0pm_test"`
}



func (cc *SmartContract) ReadState(ctx contractapi.TransactionContextInterface) (*StateMemory, error) {
	stateJSON, err := ctx.GetStub().GetState("currentMemory")
	if err != nil {
		return nil, err
	}
	if stateJSON == nil {
		return &StateMemory{}, nil
	}

	var state StateMemory
	if err := json.Unmarshal(stateJSON, &state); err != nil {
		return nil, fmt.Errorf("failed to unmarshal state: %v", err)
	}
	return &state, nil
}

func (cc *SmartContract) UpdateState(ctx contractapi.TransactionContextInterface, state *StateMemory) error {
	stateJSON, err := json.Marshal(state)
	if err != nil {
		return fmt.Errorf("failed to marshal state: %v", err)
	}
	return ctx.GetStub().PutState("currentMemory", stateJSON)
}


func (cc *SmartContract) IsCompleted(ctx contractapi.TransactionContextInterface, elementID string) bool {
	stub := ctx.GetStub()
	data, err := stub.GetState(elementID)
	if err != nil { return false }
	if data == nil { return false }

	var stateObj struct {
		State int `json:"state"`
	}
	if err := json.Unmarshal(data, &stateObj); err != nil {
		return false
	}

	return stateObj.State == int(COMPLETED)
}

func (cc *SmartContract) CreateMessage(ctx contractapi.TransactionContextInterface,
	messageID string, sender string, receiver string, state ElementState) error {
	stub := ctx.GetStub()

	existing, err := stub.GetState(messageID)
	if err != nil { return err }
	if existing != nil {
		return fmt.Errorf("message %s already exists", messageID)
	}

	msg := &Message{
		ID:       messageID,
		Sender:   sender,
		Receiver: receiver,
		State:    state,
	}
	msgJSON, err := json.Marshal(msg)
	if err != nil { return err }
	return stub.PutState(messageID, msgJSON)
}

func (cc *SmartContract) CreateGateway(ctx contractapi.TransactionContextInterface,
	gatewayID string, state ElementState) error {
	stub := ctx.GetStub()

	existing, err := stub.GetState(gatewayID)
	if err != nil { return err }
	if existing != nil {
		return fmt.Errorf("gateway %s already exists", gatewayID)
	}

	gw := &Gateway{
		ID:    gatewayID,
		State: state,
	}
	gwJSON, err := json.Marshal(gw)
	if err != nil { return err }
	return stub.PutState(gatewayID, gwJSON)
}

func (cc *SmartContract) CreateEvent(ctx contractapi.TransactionContextInterface,
	eventID string, state ElementState) error {
	stub := ctx.GetStub()

	event := &Event{
		ID:    eventID,
		State: state,
	}
	eventJSON, err := json.Marshal(event)
	if err != nil { return err }
	return stub.PutState(eventID, eventJSON)
}


func (cc *SmartContract) ChangeGtwState(ctx contractapi.TransactionContextInterface, gatewayID string, state ElementState) error {
	stub := ctx.GetStub()

	gtwJSON, err := stub.GetState(gatewayID)
	if err != nil { return err }

	var gtw Gateway
	if err := json.Unmarshal(gtwJSON, &gtw); err != nil { return err }

	gtw.State = state
	gtwJSON, err = json.Marshal(gtw)
	if err != nil { return err }

	return stub.PutState(gatewayID, gtwJSON)
}

func (cc *SmartContract) ChangeEventState(ctx contractapi.TransactionContextInterface, eventID string, state ElementState) error {
	stub := ctx.GetStub()

	eventJSON, err := stub.GetState(eventID)
	if err != nil { return err }

	var event Event
	if err := json.Unmarshal(eventJSON, &event); err != nil { return err }

	event.State = state
	eventJSON, err = json.Marshal(event)
	if err != nil { return err }

	return stub.PutState(eventID, eventJSON)
}

func (cc *SmartContract) ChangeMsgState(ctx contractapi.TransactionContextInterface, messageID string, state ElementState) error {
	stub := ctx.GetStub()

	msgJSON, err := stub.GetState(messageID)
	if err != nil { return err }

	var msg Message
	if err := json.Unmarshal(msgJSON, &msg); err != nil { return err }

	msg.State = state
	msgJSON, err = json.Marshal(msg)
	if err != nil { return err }

	return stub.PutState(messageID, msgJSON)
}

func (cc *SmartContract) Message_0mjk0pm_Send(ctx contractapi.TransactionContextInterface, Message0mjk0pmTest string) error {
	stub := ctx.GetStub()

	msgJSON, err := stub.GetState("Message_0mjk0pm")
	if err != nil {
		return err
	}
	var msg Message
	if err := json.Unmarshal(msgJSON, &msg); err != nil {
		return err
	}

	if msg.State != ENABLED {
		return fmt.Errorf("message Message_0mjk0pm is not enabled (current state: %v)", msg.State)
	}

	clientMSP, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return err
	}
	if clientMSP != msg.Sender {
		return fmt.Errorf("participant %s is not authorized to send message %s (expected sender: %s)",
			clientMSP, "Message_0mjk0pm", msg.Sender)
	}

	state, err := cc.ReadState(ctx)
	if err != nil {
		return err
	}


	state.Message0mjk0pmTest = Message0mjk0pmTest

	if err := cc.UpdateState(ctx, state); err != nil {
		return err
	}

	if err := cc.ChangeMsgState(ctx, "Message_0mjk0pm", WAITING); err != nil {
		return err
	}

	stub.SetEvent("Message_0mjk0pm_sent", []byte("Message sent"))



	return nil
}

func (cc *SmartContract) Message_0mjk0pm_Confirm(ctx contractapi.TransactionContextInterface) error {
	stub := ctx.GetStub()

	msgJSON, err := stub.GetState("Message_0mjk0pm")
	if err != nil {
		return err
	}
	var msg Message
	if err := json.Unmarshal(msgJSON, &msg); err != nil {
		return err
	}

	if msg.State != WAITING {
		return fmt.Errorf("message Message_0mjk0pm is not waiting for confirmation")
	}

	clientMSP, err := ctx.GetClientIdentity().GetMSPID()
	if err != nil {
		return err
	}
	if clientMSP != msg.Receiver {
		return fmt.Errorf("participant %s is not authorized to confirm this message", clientMSP)
	}

	if err := cc.ChangeMsgState(ctx, "Message_0mjk0pm", COMPLETED); err != nil {
		return err
	}

    if err := cc.ChangeEventState(ctx, "Event_19b5bao", ENABLED); err != nil { return err }

	stub.SetEvent("Message_0mjk0pm_confirmed", []byte("Message confirmed"))

	

	return nil
}

func (cc *SmartContract) Event_1c2zpiz(ctx contractapi.TransactionContextInterface) error {
	stub := ctx.GetStub()

	eventJSON, err := stub.GetState("Event_1c2zpiz")
	if err != nil {
		return err
	}
	var event Event
	if err := json.Unmarshal(eventJSON, &event); err != nil {
		return err
	}

	if event.State != ENABLED {
		return fmt.Errorf("event Event_1c2zpiz is not enabled")
	}

	if err := cc.ChangeEventState(ctx, "Event_1c2zpiz", COMPLETED); err != nil {
		return err
	}

	if err := cc.ChangeMsgState(ctx, "Message_0mjk0pm", ENABLED); err != nil { return err }

	stub.SetEvent("Event_1c2zpiz_executed", []byte("Event executed"))

	

	return nil
}

func (cc *SmartContract) Event_19b5bao(ctx contractapi.TransactionContextInterface) error {
	stub := ctx.GetStub()

	eventJSON, err := stub.GetState("Event_19b5bao")
	if err != nil {
		return err
	}
	var event Event
	if err := json.Unmarshal(eventJSON, &event); err != nil {
		return err
	}

	if event.State != ENABLED {
		return fmt.Errorf("event Event_19b5bao is not enabled")
	}

	if err := cc.ChangeEventState(ctx, "Event_19b5bao", COMPLETED); err != nil {
		return err
	}

		

	stub.SetEvent("Event_19b5bao_executed", []byte("Event executed"))

	

	return nil
}


func (cc *SmartContract) ProcessInit(ctx contractapi.TransactionContextInterface) error {
	var err error
	err = cc.CreateMessage(ctx, "Message_0mjk0pm", "Org1MSP", "Org2MSP", DISABLED)
	if err != nil { return err }

	

	
	err = cc.CreateEvent(ctx, "Event_1c2zpiz", ENABLED)
	if err != nil { return err }
	err = cc.CreateEvent(ctx, "Event_19b5bao", DISABLED)
	if err != nil { return err }

	return nil
}